package org.collegemanagement.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReturnBookRequest {
    private Long loanId;
}

