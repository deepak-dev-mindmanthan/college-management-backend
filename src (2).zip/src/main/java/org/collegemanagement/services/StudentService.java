package org.collegemanagement.services;


public interface StudentService {
    long countByTeacherId(Long teacherId);
}
