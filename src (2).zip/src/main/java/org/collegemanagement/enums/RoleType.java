package org.collegemanagement.enums;

public enum RoleType {
    ROLE_SUPER_ADMIN,
    ROLE_COLLEGE_ADMIN,
    ROLE_TEACHER,
    ROLE_STUDENT,
    ROLE_PARENT,
    ROLE_ACCOUNTANT
}
