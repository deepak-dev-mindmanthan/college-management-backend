package org.collegemanagement.enums;

public enum LoanStatus {
    ISSUED,
    RETURNED
}

