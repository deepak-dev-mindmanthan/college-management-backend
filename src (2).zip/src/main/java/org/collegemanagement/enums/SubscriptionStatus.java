package org.collegemanagement.enums;

public enum SubscriptionStatus {
    ACTIVE,
    TRIAL,
    CANCELLED,
    EXPIRED
}

