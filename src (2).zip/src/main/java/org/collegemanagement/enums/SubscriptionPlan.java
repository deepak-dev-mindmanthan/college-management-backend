package org.collegemanagement.enums;

public enum SubscriptionPlan {
    STARTER,
    STANDARD,
    PREMIUM
}

