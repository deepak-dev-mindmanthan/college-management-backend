package org.collegemanagement.enums;

public enum CurrencyCode {
    USD
}

