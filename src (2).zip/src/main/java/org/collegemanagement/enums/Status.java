package org.collegemanagement.enums;

public enum Status {
    ACTIVE,    // College is active and operational
    SUSPENDED  // College is temporarily disabled
}
