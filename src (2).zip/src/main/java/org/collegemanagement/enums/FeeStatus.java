package org.collegemanagement.enums;

public enum FeeStatus {
    PENDING,
    PAID
}
