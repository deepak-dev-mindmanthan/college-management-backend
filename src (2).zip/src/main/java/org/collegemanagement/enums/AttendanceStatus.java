package org.collegemanagement.enums;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE
}
