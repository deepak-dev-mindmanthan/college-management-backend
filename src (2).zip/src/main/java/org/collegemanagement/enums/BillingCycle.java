package org.collegemanagement.enums;

public enum BillingCycle {
    MONTHLY,
    ANNUAL
}

