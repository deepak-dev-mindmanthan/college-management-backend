package org.collegemanagement.exception;


import org.collegemanagement.dto.ExceptionResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler{

    @ExceptionHandler(ResourceNotFoundException.class)
    ResponseEntity<ExceptionResponse> handleNotFoundException(Exception ex){
        return new ResponseEntity<>(new ExceptionResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage()), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({AuthenticationException.class})
    public ResponseEntity<ExceptionResponse> handleAccessDeniedException(AuthenticationException ex) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new ExceptionResponse(HttpStatus.FORBIDDEN.value(),"Access denied: " + ex.getMessage()));
    }

    @ExceptionHandler({ResourceConflictException.class})
    public ResponseEntity<ExceptionResponse> handleConflictException(ResourceConflictException  ex) {
        return ResponseEntity.status(HttpStatus.CONFLICT).body(new ExceptionResponse(HttpStatus.CONFLICT.value(),ex.getMessage()));
    }

    @ExceptionHandler({InvalidUserNameOrPasswordException.class})
    public ResponseEntity<ExceptionResponse> handleInvalidUserNameOrPasswordException(InvalidUserNameOrPasswordException  ex) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new ExceptionResponse(HttpStatus.UNAUTHORIZED.value(), ex.getMessage()));
    }

}
